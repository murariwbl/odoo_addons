# -*- coding: utf-8 -*-
#
#################################################################################
# Author      : Weblytic Labs Pvt. Ltd. (<https://store.weblyticlabs.com/>)
# Copyright(c): 2023-Present Weblytic Labs Pvt. Ltd.
# All Rights Reserved.
#
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
##################################################################################

from odoo.addons.website_sale.controllers.main import WebsiteSale
from odoo import http
from odoo.http import request
from datetime import datetime


#################  THIS CONTROLLER IS INSIDE THE PRODUCT WHEN WE CLICK ON PRODUCT  ##########3
class WebsiteSaleInherit(WebsiteSale):

    @http.route(['/shop/<model("product.template"):product>'], type='http', auth="public", website=True, sitemap=True)
    def product(self, product, category='', search='', **kwargs):
        settings = request.env['res.config.settings'].sudo().get_values()

        partner = request.env.user.partner_id
        setting_product_ids_command = settings.get("product_ids")
        setting_partner_ids_command = settings.get("customer_ids")
        setting_product_category_ids_command = settings.get("category_ids")

        allowed_product_ids = setting_product_ids_command[0][2] if setting_product_ids_command else []
        allowed_partner_ids = setting_partner_ids_command[0][2] if setting_partner_ids_command else []
        allowed_category_ids = setting_product_category_ids_command[0][
            2] if setting_product_category_ids_command else []

        show_button = False  # Initialize button visibility
        # Determine if the button should be shown based on selected filters
        if partner.id in allowed_partner_ids:
            show_button = True  # Show button if partner is allowed

        # If no filters are selected, show button for all customers
        if not allowed_product_ids and not allowed_category_ids and not allowed_partner_ids:
            show_button = True

        response = super(WebsiteSaleInherit, self).product(product, category, search, **kwargs)
        response.qcontext.update({
            'enable_pdf': settings.get("enable_pdf"),
            'button_name': settings.get("button_name"),
            'enable_header': settings.get("enable_header"),
            'enable_footer': settings.get("enable_footer"),
            'enable_pdf_product': settings.get("enable_pdf_product"),
            'enable_pdf_category': settings.get("enable_pdf_category"),
            ################## FILTER CONDITION ######################
            'allowed_product_ids': allowed_product_ids,
            'allowed_category_ids': allowed_category_ids,
            'allowed_partner_ids': allowed_partner_ids,
            'show_button': show_button
        })

        return response

    #################  THIS CONTROLLER IS THE PRODUCT CATEGORY PAGE ##########
    @http.route(['/shop', '/shop/page/<int:page>'], type='http', auth="public", website=True, sitemap=False)
    def shop(self, page=0, category=None, search='', min_price=0.0, max_price=0.0, ppg=False, **post):
        settings = request.env['res.config.settings'].sudo().get_values()
        partner = request.env.user.partner_id

        setting_product_ids_command = settings.get("product_ids")
        setting_partner_ids_command = settings.get("customer_ids")
        setting_product_category_ids_command = settings.get("category_ids")

        allowed_product_ids = setting_product_ids_command[0][2] if setting_product_ids_command else []
        allowed_partner_ids = setting_partner_ids_command[0][2] if setting_partner_ids_command else []
        allowed_category_ids = setting_product_category_ids_command[0][
            2] if setting_product_category_ids_command else []

        show_button = False  # Initialize button visibility
        # Determine if the button should be shown based on selected filters
        if partner.id in allowed_partner_ids:
            show_button = True  # Show button if partner is allowed

        response = super(WebsiteSaleInherit, self).shop(page, category, search, min_price, max_price, ppg, **post)

        response.qcontext.update({
            'enable_pdf': settings.get("enable_pdf"),
            'enable_pdf_category': settings.get("enable_pdf_category"),
            'allowed_product_ids': allowed_product_ids,
            'allowed_category_ids': allowed_category_ids,
            'allowed_partner_ids': allowed_partner_ids,
            'product_category_ids': allowed_product_ids,  # Directly pass product category IDs
        })

        return response
