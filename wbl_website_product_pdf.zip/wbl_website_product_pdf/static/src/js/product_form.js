import publicWidget from "@web/legacy/js/public/public_widget";
import { rpc } from "@web/core/network/rpc";

publicWidget.registry.DynamicPayment = publicWidget.Widget.extend({
    selector: '.js_product',
    events: {
        'click #product_pdf_view': '_onButtonClick',
        'click #selectAll': '_onSelectAll',
        'click #product_data_print': '_printInput',  // Event for print button on product
    },

    // Method for opening the modal popup
    async _onButtonClick(ev) {
        const modal = document.getElementById('message_popup');
        if (modal) {
            $(modal).modal('show');

            // Select all checkboxes when the modal opens
//            $('#selectAll').prop('checked', true);  // Check "Select All" checkbox
//            $('.form-check-input[name="selected_products"]').prop('checked', true);  // Check all product checkboxes
        } else {
            console.error('Modal not found');
        }
    },
//    this is used for select all option click
     async _onSelectAll(ev) {
        // Get the checked state of the "Select All" checkbox
        const selectAllChecked = $(ev.currentTarget).is(':checked');

        // Check or uncheck all product checkboxes based on "Select All" checkbox
        $('.form-check-input[name="selected_products"]').prop('checked', selectAllChecked);
    },

    async _printInput(ev) {
    ev.preventDefault();  // Prevent default behavior

    const product_id = $('#wbl_product_id').val();

    const allInputs = $('.form-check-input[name="selected_products"]:checked');  // Only checked inputs
    const inputData = {};

    allInputs.each(function() {
        const inputId = $(this).attr('id');
        inputData[inputId] = $(this).is(':checked');
    });

    console.log(inputData);

    // Instead of an RPC, redirect to the URL with product_id and options
    const queryString = $.param(inputData);  // Converts object to URL query string
    window.location.href = `/product/details/pdf?product_id=${product_id}&${queryString}`;
},

 });
