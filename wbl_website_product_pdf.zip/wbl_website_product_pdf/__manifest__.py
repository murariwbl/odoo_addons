# -*- coding: utf-8 -*-
#
#################################################################################
# Author      : Weblytic Labs Pvt. Ltd. (<https://store.weblyticlabs.com/>)
# Copyright(c): 2023-Present Weblytic Labs Pvt. Ltd.
# All Rights Reserved.
#
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
##################################################################################


{
    'name': 'Download Product PDF - Product Catalog - Product Sheet',
    'version': '18.0.1.0.0',
    'summary': "Product PDF download Product information PDF Customizable product PDF Product details PDF Download product specs PDF product catalog Customer product PDF Rich product information Product Brochure information Product sheet Download product guide Product page PDF Detailed product brochure Product data in PDF",
    'description': """Product PDF download Product information PDF Customizable product PDF Product details PDF Download product specs PDF product catalog Customer product PDF Rich product information Product Brochure information Product sheet Download product guide Product page PDF Detailed product brochure Product data in PDF""",
    'category': 'Website',
    'author': 'Weblytic Labs',
    'company': 'Weblytic Labs',
    'website': 'https://store.weblyticlabs.com',
    'price': '',
    'currency': '',
    'depends': ['base', 'base_setup', 'website', 'website_sale', 'sale_management', 'contacts'],
    'data': [
        'views/product_template.xml',
        'views/res_config_settings_view.xml',
        'views/product_category_template.xml',
        'reports/product_details_view.xml',
        'reports/product_details_pdf.xml',
        'reports/action_product_details_pdf.xml',
        'reports/action_product_details_view.xml',

    ],
    'assets': {
        'web.assets_frontend': [
            'wbl_website_product_pdf/static/src/js/product_form.js',
            'wbl_website_product_pdf/static/src/css/style.css',
        ],
    },
    'images': ['static/description/banner.gif'],
    'license': 'OPL-1',
    'installable': True,
    'auto_install': False,
    'application': True,
}
