# -*- coding: utf-8 -*-
#
#################################################################################
# Author      : Weblytic Labs Pvt. Ltd. (<https://store.weblyticlabs.com/>)
# Copyright(c): 2023-Present Weblytic Labs Pvt. Ltd.
# All Rights Reserved.
#
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
##################################################################################

from odoo import http
from odoo.http import request
from odoo.addons.portal.controllers.portal import CustomerPortal
from datetime import datetime, timedelta


#############   THIS CONTROLLER IS USED print THE PRODUCT DETAILS ON PRINT BUTTON CLICK   ####################
class PortalMyProductDetailsPdf(http.Controller):

    @http.route(['/product/details/pdf'], type='http', auth='public', website=True)
    def portal_my_product_details_pdf(self, product_id, **kw):
        # Fetch the system settings
        settings = request.env['res.config.settings'].sudo().get_values()

        # Fetch the product record using the product_id
        product = request.env['product.template'].sudo().browse(int(product_id))

        if not product.exists():
            return request.not_found()

        # Retrieve the options from the kw (URL query parameters)
        select_all = kw.get('selectAll', False)
        product_with_image = kw.get('productWithImage', False)
        product_with_price = kw.get('productWithPrice', False)
        product_with_description = kw.get('productWithDescription', False)
        product_with_attribute = kw.get('productWithAttributes', False)
        #############
        product_with_header = kw.get('productWithHeader')
        product_with_footer = kw.get('productWithFooter')
        product_with_pageno = kw.get('productWithPageNo', False)

        # Collect attributes and values only if productWithAttribute is True or selectAll is True
        attributes = []
        if product_with_attribute or select_all:
            for attribute_line in product.attribute_line_ids:
                attribute = attribute_line.attribute_id
                for value in attribute_line.value_ids:
                    attributes.append({
                        'attribute': attribute.name,
                        'value': value.name
                    })

        # Get product currency and price information
        currency_symbol = product.currency_id.symbol or ''  # Fetch product currency symbol
        formatted_price = f"{product.list_price:.2f}"  # Format the price to two decimal places

        current_date = datetime.today().strftime('%Y-%m-%d')

        # Build the values dictionary based on the options provided
        values = {
            'product': product,
            'name': product.name,
            'cover_image': settings.get("cover_image"),
            'display_date': settings.get("display_date"),
            'current_date': current_date,
        }

        # Conditionally add elements based on user options
        #################  THIS IS FOR LOGO ##############
        if settings.get('enable_logo') == 'True':
            values['logo_image'] = settings.get("logo_image")
            values['logo_position'] = settings.get("logo_position")
            values['enable_logo'] = True
        else:
            values['enable_logo'] = False

        ############  THIS IS FOR HEADER  #############
        if product_with_header == 'true' or select_all == 'true':
            values['header_text'] = settings.get("header_text")
        if product_with_footer == 'true' or select_all == 'true':
            values['footer_text'] = settings.get("footer_text")
        if product_with_pageno == 'true' or select_all == 'true':
            values['show_pageno'] = True
            ##############   THIS IS FOR IMAGE RELATED ###########
        if product_with_image == 'true' or select_all == 'true':
            values['image'] = product.image_1920
        if product_with_price == 'true' or select_all == 'true':
            values['list_price'] = formatted_price
            values['currency_symbol'] = currency_symbol
        if product_with_description == 'true' or select_all == 'true':
            values['description'] = product.description_ecommerce or ''
        if product_with_attribute == 'true' or select_all == 'true':
            values['attributes'] = attributes

        # Render the QWeb PDF template
        report_service = request.env['ir.actions.report']
        pdf_content, _ = report_service._render_qweb_pdf('wbl_website_product_pdf.action_report_product_template',
                                                         [product.id], data=values)

        # Create a response that triggers the file download
        response = request.make_response(pdf_content, headers=[
            ('Content-Type', 'application/pdf'),
            ('Content-Disposition', f'attachment; filename="{product.name}_details.pdf"'),
        ])
        return response


##############   THIS CONTROLLER IS USED TO VIEW THE PRODUCT DETAILS ON VIEW BUTTON CLICK ############
class PortalMyProductDetails(http.Controller):
    @http.route(['/product/details'], methods=["GET"], type='http', auth='public', website=True)
    def portal_my_product_details(self, product_id, **kw):

        settings = request.env['res.config.settings'].sudo().get_values()

        if product_id:
            product = request.env['product.template'].sudo().browse(int(product_id))

            # Collect attributes and values
            attributes = []
            for attribute_line in product.attribute_line_ids:
                attribute = attribute_line.attribute_id

                for value in attribute_line.value_ids:
                    attributes.append({
                        'attribute': attribute.name,
                        'value': value.name
                    })

            # Get other product details
            currency_symbol = product.currency_id.symbol or ''
            formatted_price = f"{product.list_price:.2f}"

            current_date = datetime.today().strftime('%Y-%m-%d')

            # Pass all values to the template
            values = {
                'product': product,
                'name': product.name,
                'list_price': formatted_price,
                'currency_symbol': currency_symbol,
                'image': product.image_1920,
                'description': product.description_ecommerce or '',
                'attributes': attributes,
                'cover_image': settings.get("cover_image"),
                'enable_logo': settings.get("enable_logo"),
                'logo_position': settings.get("logo_position"),
                'logo_image': settings.get("logo_image"),
                'header_text': settings.get("header_text"),
                'footer_text': settings.get("footer_text"),
                'display_date': settings.get("display_date"),
                'current_date': current_date  # Pass the current date
            }

            # Generate PDF using QWeb template
            pdf_content, _ = request.env['ir.actions.report']._render_qweb_pdf(
                'wbl_website_product_pdf.template_products_details_action', [product.id], values)

            # Create PDF response
            response = request.make_response(pdf_content, headers=[
                ('Content-Type', 'application/pdf'),
            ])

            return response
        return request.not_found()


##############   THIS CONTROLLER IS USED TO PRINT THE PRODUCT PDF ON PRODUCT CATEGORY PRINT BUTTON CLICK ############
class PortalMyProductDetailsPdf(http.Controller):
    @http.route(['/product/details/category/pdf'], methods=["GET"], auth='public', website=True)
    def portal_my_product_details_pdf(self, product_id, **kw):
        # Fetch the product record using the product_id
        settings = request.env['res.config.settings'].sudo().get_values()

        if product_id:
            product = request.env['product.template'].sudo().browse(int(product_id))

            # Collect attributes and values
            attributes = []
            for attribute_line in product.attribute_line_ids:
                attribute = attribute_line.attribute_id
                print("Attribute Fetched:", attribute.name)  # Check if attributes are fetched

                for value in attribute_line.value_ids:
                    print(" - Value Fetched:", value.name)  # Check if values are fetched
                    attributes.append({
                        'attribute': attribute.name,
                        'value': value.name
                    })

            # Get other product details
            currency_symbol = product.currency_id.symbol or ''
            formatted_price = f"{product.list_price:.2f}"

            current_date = datetime.today().strftime('%Y-%m-%d')

            # Pass all values to the template
            values = {
                'product': product,
                'name': product.name,
                'list_price': formatted_price,
                'currency_symbol': currency_symbol,
                'image': product.image_1920,
                'description': product.description_ecommerce or '',
                'attributes': attributes,
                'cover_image': settings.get("cover_image"),
                'enable_logo': settings.get("enable_logo"),
                'logo_position': settings.get("logo_position"),
                'logo_image': settings.get("logo_image"),
                'header_text': settings.get("header_text"),
                'footer_text': settings.get("footer_text"),
                'display_date': settings.get("display_date"),
                'current_date': current_date  # Pass the current date
            }

            # Generate the PDF using the 'ir.actions.report' service with the correct report action ID
            report_service = request.env['ir.actions.report']
            pdf_content, _ = report_service._render_qweb_pdf('wbl_website_product_pdf.template_products_details_action',
                                                             [product.id], values)

            # Create a response that triggers the file download
            response = request.make_response(pdf_content, headers=[
                ('Content-Type', 'application/pdf'),
                ('Content-Disposition', f'attachment; filename="{product.name}_details.pdf"'),
            ])

            return response
